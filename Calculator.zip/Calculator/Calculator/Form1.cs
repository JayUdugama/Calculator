﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class frmCalculator : Form
    {
        double FirstNumber;
        string Operation;
        public frmCalculator()
       
        {
            InitializeComponent();
        }

        private void txtEnterValue_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            txtEnterValue.Text = "0";
        }

        private void ndot_Click(object sender, EventArgs e)
        {
            txtEnterValue.Text = txtEnterValue.Text + ".";
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(txtEnterValue.Text);
            txtEnterValue.Text = "0";
            Operation = "+";

        }



        private void btnMinus_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(txtEnterValue.Text);
            txtEnterValue.Text = "0";
            Operation = "-";
        }

        private void btnMultiplication_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(txtEnterValue.Text);
            txtEnterValue.Text = "0";
            Operation = "*";
        }

        private void btnDevision_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(txtEnterValue.Text);
            txtEnterValue.Text = "0";
            Operation = "/";
        }


        private void btnOne_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "1";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "1";
            }
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "2";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "2";
            }
        }


        private void btnThree_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "3";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "3";
            }
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "4";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "4";
            }
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "5";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "5";
            }

        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "6";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "6";
            }

        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "7";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "7";
            }
        }

        private void btnEight_Click(object sender, EventArgs e)
        {

            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "8";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "8";
            }
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            if (txtEnterValue.Text == "0" && txtEnterValue.Text != null)
            {
                txtEnterValue.Text = "9";
            }
            else
            {
                txtEnterValue.Text = txtEnterValue.Text + "9";
            }
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            txtEnterValue.Text = txtEnterValue.Text + "0";

        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            double SecondNumber;
            double Result;

            SecondNumber = Convert.ToDouble(txtEnterValue.Text);

            if (Operation == "+")
            {
                Result = (FirstNumber + SecondNumber);
                txtEnterValue.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "-")
            {
                Result = (FirstNumber - SecondNumber);
                txtEnterValue.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "*")
            {
                Result = (FirstNumber * SecondNumber);
                txtEnterValue.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "/")
            {
                if (SecondNumber == 0)
                {
                    txtEnterValue.Text = "Cannot divide by zero";

                }
                else
                {
                    Result = (FirstNumber / SecondNumber);
                    txtEnterValue.Text = Convert.ToString(Result);
                    FirstNumber = Result;
                }
            }
        }
    }
}
